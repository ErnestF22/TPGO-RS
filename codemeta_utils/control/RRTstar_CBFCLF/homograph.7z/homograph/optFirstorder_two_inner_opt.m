%this function finds K1
function K = optFirstorder_two_inner_opt(Wb,Wl,Cb,Cl,exitDir,Ah,Ax,bx,bh,L,xe,Zmax,eCamera)


Zmax = Zmax'*blkdiag([1 1],[1 1],[1 1],[1 1]);
L=reshape(L,[],1);
Ie = blkdiag(eCamera',eCamera',eCamera',eCamera');
Ix = repmat(eye(2),4,1);
diagZmax = diag(Zmax);

nBarriers = size(Ah,1);
nConvex = size(Ax,1);
nLandmarks = length(L);

cvx_begin

variables sb S_L K(2,nLandmarks) ...
    Pb1(nConvex,nBarriers) Pb2(nLandmarks/2,nBarriers)...
    Pb3(nLandmarks,nBarriers) Pb4(nLandmarks,nBarriers)  ...
    Pl1(nConvex,1) Pl2(nLandmarks/2,1) Pl3(nLandmarks,1)...
    Pl4(nLandmarks,1)

S_B = [sb;sb;sb];      
A1 = [Ax zeros(nConvex,nLandmarks) zeros(nConvex,nLandmarks)];
A2 = [zeros(nLandmarks/2,2) Ie zeros(nLandmarks/2,nLandmarks)];
A3 = [repmat(eye(2),nLandmarks/2,1) zeros(nLandmarks,nLandmarks) diagZmax];
A4 = [zeros(nLandmarks,2) -eye(nLandmarks) eye(nLandmarks)];

A = [A1;A2;A3;A4];
A = A';
A1 = A(1:2,:);
A2 = A(3:2+nLandmarks,:);
A3 = A(3+nLandmarks:end,:);

b1 = bx;
b2 = ones(nLandmarks/2,1);
b3 = L;
b4 = zeros(nLandmarks,1);

CH1 = -Cb*Ah;
CH2 = -Ah*K;
CH3 = zeros(nBarriers,nLandmarks);


CL1 = Cl*exitDir'; 
CL2 = exitDir'*K; 
CL3 = zeros(1,nLandmarks);

b = [b1;b2;b3;b4];
% Wb'*S_B+Wl*S_L
minimize(0)

%constraints for safety:
[Pb1;Pb2;Pb3;Pb4]'*b <= Cb*bh
A1*[Pb1;Pb2;Pb3;Pb4]<=CH1'
A2*[Pb1;Pb2;Pb3;Pb4]<=CH2'
A3*[Pb1;Pb2;Pb3;Pb4]<=CH3'
Pb1>=0
Pb4>=0

%constraints for stability:
[Pl1;Pl2;Pl3;Pl4]'*b <= Cl*exitDir'*xe
A1*[Pl1;Pl2;Pl3;Pl4]<=CL1'
A2*[Pl1;Pl2;Pl3;Pl4]<=CL2'
A3*[Pl1;Pl2;Pl3;Pl4]<=CL3'
Pl1>=0
Pl4>=0

% % 
% K*ones(8,1)==[Cb;Cb]
% K*reshape(L,[],1) == Cb*xe
% 
% K*kron(ones(4,1),eye(2)) == [Cb 0;0 Cb]
% K*reshape(L,[],1) == K*kron(ones(4,1),eye(2))*xe

cvx_end

 end



