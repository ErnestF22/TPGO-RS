function [sMin,sMax] = MinMaxDis(y,L)
sMin = inf*ones(size(L,2),1);
sMax = zeros(size(L,2),1);
for i=1:size(L,2)
    for j=1:size(y,2)
        t = 1/norm(L(:,i)-y(:,j));
        if t<=sMin(i)
            sMin(i)=t;
        end
        if t>sMax(i)
            sMax(i)=t;
        end
    end
end
end