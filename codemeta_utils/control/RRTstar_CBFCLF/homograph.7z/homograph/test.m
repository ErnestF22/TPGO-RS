clear 
close all

y = [2 1;1.5 8;11.5 6.1;11 4.5]'; %general
% y = [2 2;1.5 6.5;11.5 16.5;11 11]'; %parallel
% y = [2 3.5;1.5 8.5;10 13;9 6]'; %open set
L = [12 8;12 1;16 10;18 1]';
% L = y;


p = (y(:,2)+y(:,4))/2;
[A,b] = convexSet(y);
[Ax,bx] = LPSet(A,b,p);

Ah = -Ax;
bh = bx;


Ah(3,:)=[];
bh(3)=[];



exitDir =  -Ax(3,:)';
exitDir = exitDir/norm(exitDir);

% xe = intersectionTwoLines(A(2,1),b(2),A(4,1),b(4));
xe = (y(:,3)+y(:,4))/2;


epsilon = 2;

Wb = 1*ones(size(Ah,1),1);
Wl = 1;



E = [1;0];
% 0: translation
% 1: bearing 
flag = 1;

if flag == 0% for in and KY cl=1 and cb=0.5
    Cl = 1;
    Cb = 1.2; 
else 
    Cl = 1;
    Cb = 1.2; % for optWithS = Cl=1 and Cb = 0.2
end

[K] = find_controller(exitDir,Wb,Wl,Ah,Ax,bx,bh,xe,y,L,Cl,Cb,E,flag);

plot_controllers(Ax,bx,K,L,epsilon,flag,xe,E)
plot(xe(1),xe(2),'c*')
grid on

for i=1:size(y,2)
    plot(y(1,i),y(2,i),'b*')
    hold on
end

for i=1:size(L,2)
    plot(L(1,i),L(2,i),'g*')
    hold on
end

plot( y(1,:), y(2,:), '.-r');
hold on
plot( [y(1,end) y(1,1)],[y(2,end) y(2,1)], '.-r');
axis([0 20 0 10])
axis equal
axis([0 25 0 15])

