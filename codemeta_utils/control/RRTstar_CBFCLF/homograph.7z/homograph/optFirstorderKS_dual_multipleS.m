%this function finds K1
function [K] = optFirstorderKS_dual_multipleS(Wb,Wl,Cb,Cl,z,Ah,Ax,bx,bh,L,xe,Smax)
Smax = [10;10;10;10];
%Wb:steering factor for cbf
%Wl:steering factor for clf
%Cb:cbf coefficoient
%Cl:clf coefficoient
%z:exit direction
%Ah:barrier matrix
%bh:barrier bias
%Au:velocity matrix
%bu:velocity bias
%Ax:convex cell matrix
%bx:convex cell bias
%Y: vectorized of landmarks
%d:dimestion

I=kron(ones(size(L,2),1),eye(2));
L=reshape(L,[],1);

nBarriers = size(Ah,1);
nConvex = size(Ax,1);
nLandmark = length(L);

cvx_begin
%Sb(nBarriers,1) S_l Su
variables k1(2,2) k2(2,2) k3(2,2) k4(2,2)...
    lB(nConvex,nBarriers) lL(nConvex,1) P1(3,4) P2(3,4) P3(2,4) P4(2,4)

minimize(1)

K = blkdiag(k1,k2,k3,k4);
As1 = blkdiag(Ah(1,:),Ah(1,:),Ah(1,:),Ah(1,:));
As2 = blkdiag(Ah(2,:),Ah(2,:),Ah(2,:),Ah(2,:)); 
As3 = blkdiag(Ah(3,:),Ah(3,:),Ah(3,:),Ah(3,:)); 
Ahs = [(As1*K*L)';(As2*K*L)';(As3*K*L)'];
Als = blkdiag(z',z',z',z'); 

subject to
%constraints for safety:
P1*Smax <= (Cb*bh)-lB'*bx
P1>=-Ahs
P1>=0

P2*[Smax Smax] == -(Ah*Cb)-lB'*Ax
P2>=-(Ahs)
P2>=0

%constraints for stability:
P3*Smax<= (Cl*z'*xe)'-bx'*lL
P3'>= Als*K*I
P3>=0

P4*Smax == (z'*Cl)'-Ax'*lL
P4'>= Als*K*I
P4>=0

lB>=0
lL>=0

[k1 k2 k3 k4]*kron(ones(4,1),eye(2)) == [Cb 0;0 Cb]
[k1 k2 k3 k4]*reshape(L,[],1) == [k1 k2 k3 k4]*kron(ones(4,1),eye(2))*xe

cvx_end
K = [k1 k2 k3 k4];
end



