    %this function finds K1
function [K1] = optFirstorder_dual_for_S(Wb,Wl,Cb,Cl,z,Ah,Ax,bx,bh,y,xe)
%Wb:steering factor for cbf
%Wl:steering factor for clf
%Cb:cbf coefficoient
%Cl:clf coefficoient
%z:exit direction 
%Ah:barrier matrix
%bh:barrier bias
%Au:velocity matrix
%bu:velocity bias
%Ax:convex cell matrix
%bx:convex cell bias
%Y: vectorized of landmarks
%d:dimestion
Y=zeros(2*size(y,2),1);
for i=1:size(y,2)
    Y(2*i-1)=y(1,i);
    Y(2*i)=y(2,i);
end
nBarriers = size(Ah,1);
nConvex = size(Ax,1);
nLandmark=length(Y);
I=kron(ones(size(y,2),1),eye(2));

cvx_begin

    variables Sb(nBarriers,1) S_l Su K1(2,nLandmark) ...
              lB(nConvex,nBarriers) lL(nConvex,1) ...
              s1 s2 s3 s4 s5 
          
S = [s1 0 0 0 0 0 0 0;
     0 s1 0 0 0 0 0 0;
     0 0 s2 0 0 0 0 0;
     0 0 0 s2 0 0 0 0;
     0 0 0 0 s3 0 0 0;
     0 0 0 0 0 s3 0 0;
     0 0 0 0 0 0 s4 0;
     0 0 0 0 0 0 0 s4];
 
    minimize(Wb'*Sb+Wl*S_l)

    subject to
    
    %constraints for safety:
    bx'*lB <= Sb'+Cb*bh'+Y'*K1'*Ah'
    Ax'*lB == (Ah*K1*I-Ah*Cb)'
    
    %constraints for stability:
    bx'*lL<= S_l-z'*K1*Y+Cl*z'*xe
    Ax'*lL == (-z'*K1*I+z'*Cl)'
       

        lB>=0
        lL>=0
        Sb<=0
        S_l<=0
        
cvx_end
end