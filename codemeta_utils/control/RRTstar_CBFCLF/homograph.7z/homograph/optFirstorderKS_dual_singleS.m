%this function finds K1
function [K] = optFirstorderKS_dual_singleS(Wb,Wl,Cb,Cl,z,Ah,Ax,bx,bh,L,xe,Smax)

%Wb:steering factor for cbf
%Wl:steering factor for clf
%Cb:cbf coefficoient
%Cl:clf coefficoient
%z:exit direction
%Ah:barrier matrix
%bh:barrier bias
%Au:velocity matrix
%bu:velocity bias
%Ax:convex cell matrix
%bx:convex cell bias
%Y: vectorized of landmarks
%d:dimestion

I=kron(ones(size(L,2),1),eye(2));
L=reshape(L,[],1);

nBarriers = size(Ah,1);
nConvex = size(Ax,1);
nLandmark = length(L);

cvx_begin
%Sb(nBarriers,1) S_l Su
variables K(2,nLandmark) ...
    lB(nConvex,nBarriers) lL(nConvex,1) P1(1,3) P2(2,3) P3 P4

minimize(1)

subject to
%constraints for safety:
P1*Smax <= (Cb*bh)'-bx'*lB
P1>=-(Ah*K*L)'
P1>=0

P2*Smax == -(Ah*Cb)'-Ax'*lB
P2>=-(Ah*K*I)'
P2>=0

%constraints for stability:
P3*Smax<= (Cl*z'*xe)'-bx'*lL
P3>=z'*K*L
P3>=0

P4*Smax == (z'*Cl)'-Ax'*lL
P4>=z'*K*I
P4>=0

lB>=0
lL>=0

K*kron(ones(4,1),eye(2)) == [Cb 0;0 Cb]
K*reshape(L,[],1) == K*kron(ones(4,1),eye(2))*xe

cvx_end
end



