function output = find_controller(exitD,Wb,Wl,Ah,Ax,bx,bh,xe,y,L,Cl,Cb,E,flag)
Zmax=15;                        
if flag == 0
    [K,y1,y2,y3,y4] = optFirstorderWithU(Wb,Wl,Cb,Cl,exitD,Ah,Ax,bx,bh,L,xe);
    output = K;
else
    %   K = optFirstorder_two_inner_opt_summation(Wb,Wl,Cb,Cl,exitD,Ah,Ax,bx,bh,L,xe,Zmax,E);
    [sMin,sMax] = MinMaxDis(y,L);
%     K =  optFirstorderWithS(Wb,Wl,Cb,Cl,exitD,Ah,Ax,bx,bh,L,xe,sMin*0,sMax*0.2);
    K = optFirstorder_two_inner_opt_withoutPb(Wb,Wl,Cb,Cl,exitD,Ah,Ax,bx,bh,L,xe,Zmax,E);
    output = K;
end
end