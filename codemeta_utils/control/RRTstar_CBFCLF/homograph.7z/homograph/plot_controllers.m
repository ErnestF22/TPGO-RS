function plot_controllers(A,b,k,y,e,flag,xe,E)
X=0:e:20;
Y=0:e:15;
c=0;
k1=k(:,1:2);
k2=k(:,3:4);
k3=k(:,5:6);
k4=k(:,7:8);
for i=1:size(X,2)
    for j=1:size(Y,2)
        x = [X(i);Y(j)];
%           if all(A*x<b)
            c=c+1;
            v=(y-x*ones(1,size(y,2)));
            if flag == 1
                v = bearing(v,E);
            end
            v = reshape(v,[],1);
            u= k*v;
            quiver(x(1),x(2),u(1),u(2),'Color', [0.75 0.75 0.75])
            hold on
%           end
    end
end
end