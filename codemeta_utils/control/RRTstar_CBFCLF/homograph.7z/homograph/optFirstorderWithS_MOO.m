%this function finds K1
function [K] = optFirstorderWithS_MOO(Wb,Wl,Cb,Cl,z,Ah,Ax,bx,bh,L,xe,zMin,zMax)
%Wb:steering factor for cbf
%Wl:steering factor for clf
%Cb:cbf coefficoient
%Cl:clf coefficoient
%z:exit direction
%Ah:barrier matrix
%bh:barrier bias
%Au:velocity matrix
%bu:velocity bias
%Ax:convex cell matrix
%bx:convex cell bias
%Y: vectorized of landmarks
%d:dimestion

nLandmark = length(L);
I=kron(ones(size(L,2),1),eye(2));
L1 = blkdiag(L(:,1),L(:,2),L(:,3),L(:,4));
L2 = reshape(L,[],1);
nBarriers = size(Ah,1);
nConvex = size(Ax,1);

cvx_begin
variables  S_l K(2,nLandmark*2) sb ...
    lB(nConvex,nBarriers) lL(nConvex,1)...
    P1(4,1) P2(4,1)
a1=0; b1=0; 
for i=1:nBarriers
    ah = Ah(i,:);
    a1= a1+(-ah*K*L1)';
    b1 = b1+(sb+Cb*bh(i))'-bx'*lB(:,i);
end
a2=0; b2=0; 
for i=1:nBarriers
    ah = Ah(i,:)';
    a2= a2+ -([1 0]*K*kron(eye(nLandmark),ah))';
    b2 = b2+[1 0]*(-ah*Cb-Ax'*lB(:,i));
end
a3=0; b3=0; 
for i=1:nBarriers
    ah = Ah(i,:)';
    a3= a3+ -([0 1]*K*kron(eye(nLandmark),ah))';
    b3 = b3+[0 1]*(-ah*Cb-Ax'*lB(:,i));
end
a4 = (z'*K*L1)';
b4 = (S_l+Cl*z'*xe)-bx'*lL;
a5 = ([1 0]*K*kron(eye(nLandmark),z))';
b5 = [1 0]*(z*Cl-Ax'*lL);
a6 = ([0 1]*K*kron(eye(nLandmark),z))';
b6 = [0 1]*(z*Cl-Ax'*lL);

minimize(sb+S_l)
subject to
[-zMin' zMax']*[P1;P2]<=b1+b2+b3+b4+b5+b6
[-eye(4) eye(4)]*[P1;P2]==a1+a2+a3+a4+a5+a6
%constraints for safety:
K>=1
lB>=0
lL>=0
sb<=0
S_l<=0
sb>=-0.1
S_l>=-0.1
P1>=0
P2>=0
cvx_end
end



% Sb = [sb;sb;sb];
% CB = [(Sb+Cb*bh)'-bx'*lB [1 0]*(-Ah'*Cb-Ax'*lB) [1 0]*(-Ah'*Cb-Ax'*lB)];
% CL = [(S_l+Cl*z'*xe)-bx'*lL [1 0]*(z*Cl-Ax'*lL) [0 1]*(z*Cl-Ax'*lL)];
% CS = [zMax' -zMin'];
% C = [CB CL CS];
% minimize(C*[P1;P2;P3;P4;P5;P6;P7;P8])
